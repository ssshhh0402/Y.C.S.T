package DTO;

public class User {
    public long id, from;

    public User(long a, long b){
        this.id = a;

        this.from = b;
    }

}
